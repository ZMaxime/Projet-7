## Installation des dépendances

Pour exécuter ce projet, vous devez installer les dépendances suivantes :

- axios
- bcrypt
- cors
- express
- jsonwebtoken
- mongoose
- mongoose-unique-validator
- multer
- sharp